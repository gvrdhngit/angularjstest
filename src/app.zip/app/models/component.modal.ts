export interface ShowCheck{
    id:string;
    name:string;
}